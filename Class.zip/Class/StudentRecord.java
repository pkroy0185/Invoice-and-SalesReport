public class StudentRecord
{
   private String name;
   private String address;
   private double mathGrade;
   private double englishGrade;
   private double scienceGrade;   
   public StudentRecord()
   {
       //someinitializationcodehere
   }
   public StudentRecord(String temp)
   {
     this.name=temp;
   }
   public StudentRecord(String name,String address)
   {
     this.name=name;
     this.address=address;
   }
   public StudentRecord(double mGrade,double eGrade,double sGrade)
   {
     mathGrade=mGrade;
     englishGrade=eGrade;
     scienceGrade=sGrade;
   }
   public void Display()
   {
	 System.out.println("\tName :: "+name);
	 System.out.println("\tAddress :: "+address);
	 System.out.println("\tMath Grade :: "+mathGrade);
	 System.out.println("\tEnglish Grade :: "+englishGrade);
	 System.out.println("\tScience Grade :: "+scienceGrade);
   }
   public static void main(String[] args)
   {
     //createthreeobjectsforStudentrecord
     StudentRecord annaRecord=new StudentRecord("Anna");
     StudentRecord beahRecord=new StudentRecord("Beah","Philippines");
     StudentRecord crisRecord=new StudentRecord(80,90,100);
	 annaRecord.Display();
	 beahRecord.Display();
	 crisRecord.Display();
   }


//somecodehere
}