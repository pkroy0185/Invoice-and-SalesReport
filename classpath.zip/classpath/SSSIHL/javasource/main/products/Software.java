package main.products;
public class Software extends Product
{
	 private String version;
	 public Software()
	 {
		 super();
		 count++;
		 version="";
	 }
	 public void setVersion(String Version)
	 {
		 version=Version;
	 }
	 public String getVersion()
	 {
		 return version;
	 }
	 public String toString()
    {
        return super.toString()+ "Version: " + version + "\n" ;
    }
}