/*
    By Pintu Roy
	On 23/02/2021
	                                                                                                 */
public class TestSorter
{
	public static void main(String args[])
	{
		try
		{
			ArraySorter AS= new ArraySorter(Integer.parseInt(args[2]));
			AS.getSorted(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
		    AS.displayArray();  
		}
		catch(ArrayIndexOutOfBoundsException exc1)
		{
			ArraySorter AS= new ArraySorter();
            AS.getSorted(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
		    AS.displayArray();
		}
		catch(IllegalArgumentException exc)
		{
			System.out.println("Error : "+exc.getMessage());
		}
	}
}