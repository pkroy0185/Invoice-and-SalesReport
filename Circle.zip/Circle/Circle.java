/*
        By Pintu Roy
		on 4/02/21
		                                                              */
import java.text.*; 
public class Circle
{
   private double radius;
   private double area;
   private double circumference;
   private static int count;
   public Circle(double r)
   {
      radius=r;
	  count++;
   }
   public double getCircumference()
   {
      circumference=2*Math.PI*radius;
	  return circumference;
   }
   public String getFormattedCircumference()
   {
	   NumberFormat NF=NumberFormat.getInstance();
	   NF.setMaximumFractionDigits(3);
	   return NF.format(this.getCircumference()); 
   }
   public double getArea()
   {
	   area=Math.PI*Math.pow(radius,2);
	   return area;
   }
   public String getFormattedArea()
   {
	   NumberFormat NF=NumberFormat.getInstance();
	   NF.setMaximumFractionDigits(3);
	   return NF.format(this.getArea());
   }
   public static int getObjectCount()
   {
	   return count;
   }
}