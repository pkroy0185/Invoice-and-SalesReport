/*
        By Pintu Roy
		on 4/02/21
		                                                              */
import java.util.Scanner;
public class CircleTester
{
	public static void main(String[] args)
		{
			double radius;
			String choice;
			System.out.println("Welcome to the Circle Tester...");
			while(true)
			{
			   radius=Validator.getDouble("Enter Radius : ");
			   Circle circle=new Circle(radius);
			   System.out.println("Circumference : "+circle.getFormattedCircumference()+" unit");
			   System.out.println("Area          : "+circle.getFormattedArea()+" unit^2");
			   while(true)
			   {
			     choice=Validator.getString("continue(y/n)? : ");
			     if(choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("n"))
				   break;
			     else
				   System.out.println("Invalid input....");
			   }
			   if(choice.equalsIgnoreCase("n"))
			   {
			     System.out.println("Goodbye. You created "+circle.getObjectCount()+" circle object(s).");
			     break;  
			   }
			}	
			System.out.println("Press any key to continue....");
			Scanner sc=new Scanner(System.in);
		    choice=sc.next();
		}
}