package main.products.interfaces;
public interface Tagable
{
	public String getTags();
	public void setTags(String tag);
}
