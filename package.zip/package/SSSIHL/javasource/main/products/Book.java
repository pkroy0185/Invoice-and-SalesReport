package main.products;

import main.products.Product;

public class Book extends Product
{
	 private String Author;
	 public Book()
	 {
		 super();
		 count++;
		 Author="";
	 }
	 public void setAuthor(String author)
	 {
		 Author=author;
	 }
	 public String getAuthor()
	 {
		 return Author;
	 }
	 public String toString()
    {
        return super.toString()+ "Author: " + Author + "\n" ;
    }
}