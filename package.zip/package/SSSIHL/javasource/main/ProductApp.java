/*
        By Pintu Roy
		on 16/02/21
		                                                              */
package main;

import java.util.Arrays;
import main.utility.*;
import main.products.*;
import main.products.db.*;

public class ProductApp
{
	public static void main(String[] args)
		{
		    Product PArray[]=new Product[10];
			Product P=new Product();
			String code,choice;
			int total;
			while(true)
			{
			   code=Validator.getString("Enter the code of the product : ");
			   P=ProductDB.getProduct(code);
			   total=Product.getCount();
			   if(P==null)
			    System.out.println("No product matches this product code.");
			   else
			     PArray[P.getCount()-1]=P;
			   System.out.println("You have created "+Product.getCount()+" Products so far..");
			   while(true)
			   {
			     choice=Validator.getString("continue(y/n)? : ");
			     if(choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("n"))
				   break;
			     else
				   System.out.println("Invalid input....");
			   }
			   if(choice.equalsIgnoreCase("n"))
			     break;
			}
			Arrays.sort(PArray,0,Product.getCount());
            total=PArray[0].getCount();			
			System.out.println("Details of all products entered by user ....");
			for(int i=0;i<total;i++)
			   System.out.println(PArray[i].toString());
		}
}