/*
        By Pintu Roy
		on 22/03/21
		                                                              */
////////////////////Package Name////////////////////////
package main.products.interfaces;
////////////////////////////////////////////////////////

/////////////Definition of Interface Tagable////////////
public interface Tagable
{
	public String getTags();
	public void setTags(String tag);
}
////////////////////////////////////////////////////////
