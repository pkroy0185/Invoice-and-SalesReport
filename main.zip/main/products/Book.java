/*
        By Pintu Roy
		on 22/03/21
		                                                              */
////////////////////Package Name////////////////////////
package main.products;
////////////////////////////////////////////////////////

///////////////Definition of class Book/////////////////
public class Book extends Product
{
	 private String Author;
	 public Book()
	 {
		 super();
		 Author="";
	 }
	 public void setAuthor(String author)
	 {
		 Author=author;
	 }
	 public String getAuthor()
	 {
		 return Author;
	 }
}
////////////////////////////////////////////////////////