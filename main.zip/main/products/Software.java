/*
        By Pintu Roy
		on 22/03/21
		                                                              */
////////////////////Package Name////////////////////////
package main.products;
////////////////////////////////////////////////////////

///////////////Definition of class Software/////////////
public class Software extends Product
{
	 private String version;
	 public Software()
	 {
		 super();
		 version="";
	 }
	 public void setVersion(String Version)
	 {
		 version=Version;
	 }
	 public String getVersion()
	 {
		 return version;
	 }
}
////////////////////////////////////////////////////////