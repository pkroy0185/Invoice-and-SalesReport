/*
        By Pintu Roy
		on 22/03/21
		                                                              */
////////////////////Package Name////////////////////////
package main.invoice;
////////////////////////////////////////////////////////

///////////////Importing required libraries/////////////
import main.products.*;
import main.products.db.*;
////////////////////////////////////////////////////////

////////////////////Class ProductOrder//////////////////
public class ProductOrder implements Comparable<ProductOrder>
{
	private Product product;
	private int quantity;
	private Double total;
	private static int orderObjectCount;
	public ProductOrder()
	{
		quantity=0;
		total=0.0;
		product=new Product();
	}
    public ProductOrder(String code,int qntity)
	{
		quantity=qntity;
		orderObjectCount+=quantity;
		product=ProductDB.getProduct(code);
		total=quantity*product.getPrice();
	}

    ///////////Implementing compareTo() on total//////////	
	public int compareTo(ProductOrder PO)
	{
		int val=0;
		try
		{
			val=total.compareTo(PO.total);
		}
		catch(NullPointerException ex)
		{
			System.out.println(ex.getMessage());
		}
		return val;
	}
	//////////////////////////////////////////////////////
	
	public String toString()
    {
        return "\tProduct:	" + this.product.getCode() + "\n" +
               "\tQuantity:	" + quantity + "\n" +
               "\ttotal:	 	Rs. " + total + "\n";
    }
	public void setQuantity(int qntity)
	{
		quantity=qntity;
	}
	public void setTotal(double ttl)
	{
		total=ttl;
	}
	public static int getTotalProductOrdered()
	{
		return orderObjectCount;
	}
	public Product getProduct()
	{
		return product;
	}
	public int getQuantity()
	{
		return quantity;
	}
	public double getTotal()
	{
		return total;
	}
}
////////////////////////////////////////////////////////