/*
        By Pintu Roy
		on 22/03/21
		                                                              */
////////////////////Package Name////////////////////////
package main.invoice;
////////////////////////////////////////////////////////

///////////////Importing required libraries/////////////
import main.invoice.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.*;
import java.time.*;
////////////////////////////////////////////////////////

////////////////////Class Invoice///////////////////////
public class Invoice
{
	private String invoiceNumber;
	private String date;
	private List<ProductOrder> prodOrderList = new LinkedList<ProductOrder>();
	private double total;
	public Invoice(List<ProductOrder> po_List)
	{
		total=0;
		try
		{
			///////////Finding System Date and time/////////
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now(); 
			date=dtf.format(now);
			
			////////////////////////////////////////////////
		}
		catch(IllegalArgumentException ex)
		{
			System.out.println(ex.getMessage());
		}
		/////////////////Forming InvoiceNumber from System date and time/////////////
        invoiceNumber=date.substring(0,2)+date.substring(3,5)+date.substring(6,10)+date.substring(11,13)+date.substring(14,16)+date.substring(17);		
		try
		{
			for(Iterator<ProductOrder> itr=po_List.iterator();itr.hasNext();)
				prodOrderList.add(itr.next());
		}
		catch(NoSuchElementException ex)
		{
			System.out.println(ex.getMessage());
		}
        for(ProductOrder po: prodOrderList)
            total=total+po.getTotal();
	}
	
	////////////////Function to return List Of ProductOrder//////////////
	public List<ProductOrder> getProductOrderList()
	{
		return prodOrderList;
	}
	/////////////////////////////////////////////////////////////////////
	
	////////function toString() Displays Top section of Invoice//////////
	public String toString()
    {
        return "\t\tInvoice Number:	" + invoiceNumber + "\n" +
               "\t\tDate:		" + date + "\n" +
               "\t\ttotal:       	Rs. " + total + "\n";
    }
	/////////////////////////////////////////////////////////////////////
}