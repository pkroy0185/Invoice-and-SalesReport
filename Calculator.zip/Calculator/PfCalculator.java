/*
         By Pintu Roy
		 On 4/3/2021
		                                                                         */
package Calculator;
import java.util.*; 
public class PfCalculator
{	
    public static double evaluateExp(Queue<String> queue) throws IllegalArgumentException
    {
		double value;
		Stack<Double> stack=new Stack<Double>();
		double pass;
		String popped;
		try
		{
		    popped=queue.poll();
		    do
	        {  
	            if(!(popped.equals("+") || popped.equals("-") || popped.equals("*") || popped.equals("/")|| popped.equals("^"))) 
                {   
	                stack.push(Double.parseDouble(popped));
			    }
                else
		        {  
				   pass=calculate(stack.pop(),stack.pop(),popped);
		           stack.push(pass);
				}
		        popped=queue.poll();		  
            }while(popped!=null);
		}
		catch(EmptyStackException e)
		{
			throw new IllegalArgumentException("Error : Invalid postfix expression.");
		}
		catch(NullPointerException e1)
		{
			throw new IllegalArgumentException("Error : queue is empty or inappropriate no of operands or operators ....");
		}
		if(!stack.empty())
		{
		   value=stack.pop();
		   if(!stack.empty())
			 throw new IllegalArgumentException("Error : inappropriate no of operands or operators ....");
           else		 
		     return value;
		}
		throw new IllegalArgumentException("Error : Invalid Input ....");
    }	
    private static double calculate(double op1,double op2,String op)
    {
		if(op.equals("+"))
		   return op2+op1;
	    else
	     if(op.equals("-"))
		    return op2-op1;
		 else
	      if(op.equals("*"))
		     return op2*op1;
		  else
	       if(op.equals("/"))
		      return op2/op1;
		   else
		      return Math.pow(op2,op1);
    }		
}
