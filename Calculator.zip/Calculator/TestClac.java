/*
         By Pintu Roy
		 On 4/3/2021
		                                                                         */
package Calculator;
import java.util.*;
public class TestClac
{
	public static boolean isNumeric(String str) 
	{
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
	public static void main(String args[])
	{
		Queue<String> queue=new LinkedList<>();
		String exp,choice;
		int success;
		while(true)
		{
		    exp=Validator.getString("Enter the expression(Please give a space betweeen every two tokens) : ");
		    String tokens[]=exp.split(" ");
		    success=1;
            for(String token: tokens)
	        {
			    if(isNumeric(token))
                  queue.add(token);
			    else
			    {
				    if(token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/")|| token.equals("^"))
			           queue.add(token);
				    else
				    {
					   System.out.println("Invalid Input.......");
					   success=0;
					   break;
				    }
		       }   
            }
		    if(success==1)
		    {
			    try
			    {
		         System.out.println("Result : "+PfCalculator.evaluateExp(queue));
			    }
			    catch(IllegalArgumentException e)
			    {
			   	    System.out.println(e.getMessage());
			    }
		    }
		    choice=Validator.getString("continue(y/n)? : ");
		    if(choice.equalsIgnoreCase("y"))
		    {
			    queue.clear();
	            continue;
		    }
	        else
		     break;	   
		}	
	}
}