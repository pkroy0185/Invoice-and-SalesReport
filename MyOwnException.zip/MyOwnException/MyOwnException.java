/*
    By Pintu Roy
	On 23/02/2021
	                                                                                                 */
public class MyOwnException extends IllegalArgumentException
{
	MyOwnException()
	{
		super();
	}
	MyOwnException(String exc)
	{
		super(exc);
	}
}