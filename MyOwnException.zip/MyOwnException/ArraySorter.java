/*
    By Pintu Roy
	On 23/02/2021
	                                                                                                 */
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
public class ArraySorter
{
	private int no[]=new int[20];
	ArraySorter()
	{
		this(200);
	}
	ArraySorter(int limit)
	{
		Random rnd=new Random();
		for(int i=0;i<20;i++)
		{
			no[i]=rnd.nextInt(limit);
		}
	}
	public void getSorted(int from,int to) throws MyOwnException 
	{
		try
		{
			Arrays.sort(no,from,to);
	    }
		catch(ArrayIndexOutOfBoundsException exc)
		{
			System.out.println("Error : "+exc.getMessage());
		}
		catch(IllegalArgumentException exc)
		{
		  throw new MyOwnException("FromIndex > ToIndex");
		}
	}
	public void displayArray()
	{
		for(int i=0;i<10;i++)
			System.out.print(no[i]+" ");
		System.out.print("\n");
		for(int i=10;i<20;i++)
			System.out.print(no[i]+" ");
	}
	public void Dispose()
	{
		no=null;
	}
}