/*
        By Pintu Roy
		on 22/03/21
		                                                              */
////////////////////Package Name////////////////////////
package main.invoice;
////////////////////////////////////////////////////////

///////////////Importing required libraries/////////////
import main.invoice.*;
import main.products.*;
import java.util.*;
////////////////////////////////////////////////////////

////////////////////Class SalesOrder////////////////////
public class SalesOrder
{
	private Map<String,ProductOrder> salesOrder = new HashMap<>();
	
	//////////////////Function to put Code and ProductOrder in Map//////////
	public void salesReportMap(List<Invoice> invoice)
	{
		ProductOrder PO[]=new ProductOrder[5];
		for(int i=0;i<5;i++)
			PO[i]=new ProductOrder();
		for(Invoice invc: invoice)
		{
			List<ProductOrder> prodOrderList=invc.getProductOrderList();
			for(ProductOrder po: prodOrderList)
			{
				switch(po.getProduct().getCode().toLowerCase())
				{
					case "java":
					            PO[0].getProduct().setCode("java");
					            PO[0].setQuantity(PO[0].getQuantity()+po.getQuantity());
								PO[0].setTotal(PO[0].getTotal()+po.getTotal());
								break;
					case "jsps":
					            PO[1].getProduct().setCode("jsps");
					            PO[1].setQuantity(PO[1].getQuantity()+po.getQuantity());
								PO[1].setTotal(PO[1].getTotal()+po.getTotal());
								break;
					case "mcb2":
					            PO[2].getProduct().setCode("mcb2");
					            PO[2].setQuantity(PO[2].getQuantity()+po.getQuantity());
								PO[2].setTotal(PO[2].getTotal()+po.getTotal());
								break;
					case "txtpd":
					            PO[3].getProduct().setCode("txtpd");
					            PO[3].setQuantity(PO[3].getQuantity()+po.getQuantity());
								PO[3].setTotal(PO[3].getTotal()+po.getTotal());
								break;
					case "wrdpd":
					            PO[4].getProduct().setCode("wrdpd");
					            PO[4].setQuantity(PO[4].getQuantity()+po.getQuantity());
								PO[4].setTotal(PO[4].getTotal()+po.getTotal());
					            
				}
			}
               
		}
		for(int i=0;i<5;i++)
			salesOrder.put(PO[i].getProduct().getCode(),PO[i]);
	}
	////////////////////////////////////////////////////////////////////////////
	
	////////////////////Function to Display Sales Report///////////////////
	public void displaySalesReport()
	{
		ProductOrder PO;
		System.out.println("\t.............................Sales Report.............................................");
		System.out.println("\t......................................................................................");
		System.out.println("\tProduct Code\t\t"+"Quantity\t\t"+"Price\t\t\t"+"Total");
		for (Map.Entry<String,ProductOrder> entry : salesOrder.entrySet())
        {  
	         PO=entry.getValue();
			 if(PO.getQuantity()!=0)
			 {
	             System.out.print("\t"+entry.getKey());  
                 System.out.println("\t\t\t"+PO.getQuantity()+"\t\t\tRs. "+PO.getTotal()/PO.getQuantity()+"\t\tRs. "+PO.getTotal());
			 }				 
        }   
		System.out.println("\t......................................................................................");
	}
	////////////////////////////////////////////////////////////////////////
	
}