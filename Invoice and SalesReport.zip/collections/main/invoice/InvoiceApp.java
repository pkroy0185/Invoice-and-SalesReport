/*
        By Pintu Roy
		on 22/03/21
		                                                              */
////////////////////Package Name////////////////////////																	  
package main.invoice;
////////////////////////////////////////////////////////

///////////////Importing required libraries/////////////
import java.util.Scanner;
import main.products.*;
import main.products.db.*;
import main.invoice.*;
import main.utility.*;
import java.util.*;
////////////////////////////////////////////////////////

////////////////////Class InvoiceApp////////////////////
public class InvoiceApp
{
	public static void main(String[] args)
		{
			List<Invoice> invoiceList = new LinkedList<Invoice>();
			Product P=new Product();
			String code,choice="n";
			int total,quantity,countLastOrdered=0;
			System.out.println("Welcome to Roy's MegaMart.....");
			while(true)
			{
				List<ProductOrder> prodOrderList = new LinkedList<ProductOrder>();
			    while(true)
			    {
					try
					{
						if(choice.equals("n"))
							choice=Validator.getString("Would you like to place an order?(y/n) : ");
						else
							break;
						if(choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("n"))
							break;
						else
							System.out.println("Invalid input....");
					}
					catch(NullPointerException ex)
					{
						System.out.println(ex.getMessage());
					}
					catch(InputMismatchException ex)
					{
						System.out.println(ex.getMessage());
					}
				}
				if(choice.equalsIgnoreCase("n"))
					break;
				while(true)
				{
					try
					{
						code=Validator.getString("Enter the code of the product : ");
						P=ProductDB.getProduct(code);  
						if(P==null)
							System.out.println("Sorry, This product is unavailable....");
						else
						{
							quantity=Validator.getInt("Enter the Quantity of the product : ");
							if(quantity>0)
							{
								ProductOrder PO=new ProductOrder(code,quantity);
								try
								{
									prodOrderList.add(PO);                     // Adding to list of ProductOrder
								}
								catch(IllegalArgumentException ex)
								{
									System.out.println(ex.getMessage());
								}
							}
						}
					}
					catch(NullPointerException ex)
					{	
						System.out.println(ex.getMessage());
					}
					catch(InputMismatchException ex)
					{
						System.out.println(ex.getMessage());
					}
					while(true)
					{
						try
						{
							choice=Validator.getString("continue(y/n)? : ");
							if(choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("n"))
								break;
							else
								System.out.println("Invalid input....");
						}
						catch(NullPointerException ex)
						{
							System.out.println(ex.getMessage());
						}
						catch(InputMismatchException ex)
						{
							System.out.println(ex.getMessage());
						}
			     
					}
					if(choice.equalsIgnoreCase("n"))
						break;
				}
				if(ProductOrder.getTotalProductOrdered()>0)
				{
					try
					{
						Collections.sort(prodOrderList);
					}
					catch(ClassCastException ex)
					{
						System.out.println(ex.getMessage());
					}
					catch(IllegalArgumentException ex)
					{
						System.out.println(ex.getMessage());
					}				
					System.out.println("\t....................Invoice....................");
					Invoice invoice=new Invoice(prodOrderList); 					// Passing list of ProductOrder to constructor of Invoice
					
					///////////Printing Invoice/////////////////
					
					System.out.println(invoice.toString());
					for(Iterator<ProductOrder> itr=prodOrderList.iterator();itr.hasNext();)
						System.out.println(itr.next().toString());
					System.out.println("\tTotal number of products ordered : "+(ProductOrder.getTotalProductOrdered()-countLastOrdered));
					countLastOrdered=ProductOrder.getTotalProductOrdered();
					System.out.println("\t...............................................");
					
					////////////////////////////////////////////
					
					try
					{
						invoiceList.add(invoice);
					}
					catch(IllegalArgumentException ex)
					{
						System.out.println(ex.getMessage());
					}
				}
				else
				{
					System.out.println("Sorry, You haven't ordered any products......");
				}
				while(true)
				{
					try
					{
						choice=Validator.getString("Would you like to place some more orders?(y/n) : ");
						if(choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("n"))
							break;
						else
							System.out.println("Invalid input....");
					}
					catch(NullPointerException ex)
					{
						System.out.println(ex.getMessage());
					}
					catch(InputMismatchException ex)
					{
						System.out.println(ex.getMessage());
					}
			     
				}
				if(choice.equalsIgnoreCase("n"))
				{
					System.out.println("Thaking for visiting us.......");
					break;
				}
			}
			
			//Creating Sales Report object and call of functions to create map and display report//
			
			SalesOrder salesOrder=new SalesOrder();
			if(!invoiceList.isEmpty())
			{
				salesOrder.salesReportMap(invoiceList);
			    salesOrder.displaySalesReport();
			}
			
			///////////////////////////////////////////////////////////////////////////////////////
			
		}
}

//////////////////End of Class InvoiceApp//////////////////