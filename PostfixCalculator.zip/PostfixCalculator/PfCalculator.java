package PostfixCalculator;
import java.util.*;

public class PfCalculator
{
	public static double evaluatePostfix(Queue<String> queue)
	{		System.out.println(queue.poll());
	System.out.println(queue.poll());
	System.out.println(queue.poll());
		  Stack<Double> stack = new Stack<Double>();  //Creating a new stack
		  double var1,var2,expo;
		  String pop;
          try
          {
			pop=queue.poll();
		  do
		  {
			  	
			  if(!(pop.equals("+") || pop.equals("-") || pop.equals("/") || pop.equals("*") || pop.equals("^")))
			  {
				  stack.push(Double.parseDouble(pop));;
			  }
			  else
			  {
				  var1=stack.pop();
				  var2=stack.pop();
				   switch(pop) 
					{ 
                    case "+": 
                    stack.push(var2+var1); 
                    break; 
                      
                    case "-": 
                    stack.push(var2- var1); 
                    break; 
                      
                    case "/": 
                    stack.push(var2/var1); 
                    break; 
                      
                    case "*": 
                    stack.push(var2*var1); 
                    break; 
					
					case "^":
					expo=Math.pow(var2,var1);
					stack.push(expo);
					break;
					} 
			  }
			  pop=queue.poll();
		  }while(pop!=null);
                }
                catch(EmptyStackException e)
		{
			throw new IllegalArgumentException("Error : Invalid postfix expression.");
		}
		catch(NullPointerException e1)
		{
			throw new IllegalArgumentException("Error : queue is empty or inappropriate no of operands or operators ....");
		}
		System.out.println(stack.pop());
		  return 1;
	}

}