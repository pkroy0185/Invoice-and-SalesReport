/*
     This program takes input i.e. numerator and denominator from user and performs various operations on it.
	 Also calls methods like add, subtract, multiplication, and division with user input and 6/7.
	                                                                                                                               */
public class MAIN
{
	public static void main(String[] args)
		{
			int num,den,gcd;
			double DV;
			num=Validator.getInt("Enter Numerator : ");
			den=Validator.getInt("Enter Denominator : ");
			RationalNumber rn1=new RationalNumber(num,den);
			RationalNumber rn2=new RationalNumber(6,7);
			RationalNumber rn3=new RationalNumber();
			System.out.println("The GCD of "+num+" and "+den+" is : "+rn1.getGcd());
			System.out.println("The rational number is : "+rn1.getNumerator()+"/"+rn1.getDenominator());
			DV=rn1.getDoubleValue();
			System.out.println("The Quotient is : "+DV);
			rn3=rn1.add(rn2);
			System.out.println("Sum of Rational number and 6/7 : "+rn3.getNumerator()+"/"+rn3.getDenominator());
			rn3=rn1.subtract(rn2);
			System.out.println("Difference of Rational number and 6/7 : "+rn3.getNumerator()+"/"+rn3.getDenominator());
			rn3=rn1.multiplication(rn2);
			System.out.println("Product of Rational number and 6/7 : "+rn3.getNumerator()+"/"+rn3.getDenominator());
			rn3=rn1.division(rn2);
			System.out.println("Division of Rational number and 6/7 : "+rn3.getNumerator()+"/"+rn3.getDenominator());	
		}
}