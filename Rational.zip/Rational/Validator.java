/*   This program validates the input given by the user     */
import java.util.Scanner;
public class Validator
{
	 public static int getInt(String prompt)
    {
		Scanner sc=new Scanner(System.in);
        int input=0;
        boolean isValid=false;
        while (isValid==false)
        {
            System.out.print(prompt);
            if (sc.hasNextInt())
            {
                input = sc.nextInt();
                isValid = true;
            }
            else
            {
                System.out.println("Error! Invalid integer value. Try again.");
            }
            sc.nextLine();  // discards any other data entered in the line
        }
        return input;
    }
}
				 
		