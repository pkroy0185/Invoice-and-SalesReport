
import java.util.Scanner;
public class BMI
{
 public static void main(String[] args) 
  {
   float W,H;
   float BMI;
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter Weight(in kg) : ");
   W=sc.nextFloat();
   System.out.println("Enter Height(in metres) : ");
   H=sc.nextFloat();
   BMI=W/(H*H);
   if((BMI<18.5)==true)  
     System.out.println("Underweight");
   else
    if(((BMI>=18.5)&&(BMI<25))==true)   
     System.out.println("Normal");
   else
    if(((BMI>=25)&&(BMI<30))==true)   
     System.out.println("Overweight");
   else   
    System.out.println("Too Muscular");
  }
}
