

public class Declaration
{
  public static void main(String[] arg)  
  {
     boolean result=false;
     char option;
     option='C';
     double grade = 0.0;
     System.out.println("\nresult= "+result+"\noption= "+option+"\ngrade= "+grade);
  }
}
