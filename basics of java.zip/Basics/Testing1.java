

public class Testing1 {

  public static void main(String[] args) {
   int i=0,j=10;
   boolean test= false;
   //demonstrate &&
   test = (i > 10) && (j++ > 9);
   System.out.println("i= "+i);
   System.out.println("j= "+j);
   System.out.println("test= "+test);
   //demonstrate &
   test = (i > 10) & (j++ > 9);
   System.out.println("i= "+i);
   System.out.println("j= "+j);
   System.out.println("test= "+test);
  }
}
