public class DoWhile
{
  public static void main(String[] args)
  {
    int x = 0;
    do
    {
      System.out.println(x); 
      x++; 
	}while (x<10);
	do
    {
   	  System.out.println("hello1");
	}while(false);
	do
    {	
	  System.out.println("hello");       // come out by pressing ctrl+c
	}while(true);
	
  }
}