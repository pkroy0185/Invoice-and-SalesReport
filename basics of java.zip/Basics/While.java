public class While
{
  public static void main(String[] args)
  {
    int x = 0;
    while (x<10)
    {
      System.out.println(x); 
      x++; 
	}
	//while(false)
   	 // System.out.println("hello");
	while(true) 
	  System.out.println("hello");       // come out by pressing ctrl+c
  }
}