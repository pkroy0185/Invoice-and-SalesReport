

public class NOT
{
  public static void main(String[] arg) 
  {
   boolean val1 = true;
   boolean val2 = false;
   System.out.println("!true ="+!val1);
   System.out.println("!false="+!val2);
  }
}
